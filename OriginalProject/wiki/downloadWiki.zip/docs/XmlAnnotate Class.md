# XmlAnnotate Class

Default implementation that allows comments to be included after attribute output but before element output during serialization on any classes that inherit it.

C#{code:c#}
public abstract class XmlAnnotate
{code:c#}

VB{code:vb.net}
'Declaration
Public MustInherit Class XmlAnnotate
{code:vb.net}

**Properties**

|| Name || Description || Type || Default ||
| __Comment | Serializable instance of XmlCommentElement bound to the serialized class that inherits XmlAnnotate | String | See remarks |
**Remarks**

The default value of this property is an instance of XmlCommentElement based on the type that inherits this class with behavior as specified in the four static configuration fields.

The default implementation would output an element called 'Comment' as specified in the XmlCommentElement.ElementName constant in the XML. This can be observed by serializing without using XmlCommentWriter. When XmlCommentWriter is used for serialization, this element is suppressed in the XML output because the namespace matches that which is specified in the XmlCommentElement.Namespace constant.

The instance of XmlCommentElement is not instantiated until the value is requested from the property. This ensures minimal memory footprint when using serialization classes for uses other than to output XML.

The property setter is required as properties must be writable in order for XmlSerializer to output as XML.

{code:c#}
public abstract class XmlAnnotate
{

    private XmlCommentElement _Comment;

    /// <summary>
    /// Internal property required to output comments with XmlSerializer
    /// </summary>
    [XmlElement(ElementName = XmlCommentElement.ElementName,
        Namespace = XmlCommentElement.Namespace)]
    [EditorBrowsable(EditorBrowsableState.Never)](EditorBrowsable(EditorBrowsableState.Never))
    public XmlCommentElement __Comment
    {
        get
        {
            if (_Comment == null)
                _Comment = new XmlCommentElement(this.GetType(),
                    XmlCommentElement.MaxLength, XmlCommentElement.Metadata,
                    XmlCommentElement.Repeat, XmlCommentElement.Alphabetize);
            return _Comment;
        }
        set
        {
            return; // Setter is requirement for XmlSerializer
        }
    }

}
{code:c#}