**Getting Started**

There are three steps to including comments in XML:


## [Inherit XmlAnnotate on classes that are serialized.](Getting-Started-Step-1-of-3)
## [Alter serialization code to use XmlCommentWriter.](Getting-Started-Step-2-of-3)
## [Use the XmlComment attribute and specify other settings.](Getting-Started-Step-3-of-3)
When it's not possible or desired to follow steps 1 and 2, consider [these alternatives](Alternatives).

For more information:

* [XmlAnnotate Class](XmlAnnotate-Class)
* [XmlCommentAttribute Class](XmlCommentAttribute-Class)
* [XmlCommentElement Class](XmlCommentElement-Class)
* [XmlCommentWriter Class](XmlCommentWriter-Class)
