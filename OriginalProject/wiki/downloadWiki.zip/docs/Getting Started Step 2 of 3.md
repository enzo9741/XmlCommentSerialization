**2. Use XmlCommentWriter instead of XmlWriter when serializing**

The XmlCommentWriter class inherits its capabilities from [XmlWriter](http://msdn.microsoft.com/en-us/library/system.xml.xmlwriter(v=vs.110).aspx) and provides an identical implementation. This class passes all operations to the XmlWriter but suppresses what would be a redundant Comment element from the resultant XML. Pass an instance of this class to the Serialize method. For example:  

C#{code:c#}
public void CreateOrder(Order order, FileInfo file)
{
    var settings = new XmlWriterSettings();
    settings.Indent = true;
    using (var writer = new XmlCommentWriter(file.FullName, settings))
    {
        var serialiser = new XmlSerializer(order.GetType());
        serialiser.Serialize(writer, order);
    }
}
{code:c#}

VB{code:vb.net}
Public Sub CreateOrder(ByRef Order As Order, ByRef File As FileInfo)
    Dim Settings As New XmlWriterSettings()
    Settings.Indent = True
    Using Writer As New XmlCommentWriter(File.FullName, Settings)
        Dim Serializer As New XmlSerializer(Order.GetType())
        Serializer.Serialize(Writer, Order)
    End Using
End Sub
{code:vb.net}

>{[Next Step >](Getting-Started-Step-3-of-3)}>

