# XmlCommentWriter Class

This class inherits its capabilities from XmlWriter and provides an identical implementation. This class passes all operations to the XmlWriter but suppresses what would be a redundant Comment element from the resultant XML. Pass the instance of this class to the Serialize method. This class has properties that determine the general behavior of comment output.

C#{code:c#}
public sealed class XmlCommentWriter : System.Xml.XmlWriter, System.IDisposable
{code:c#}

VB{code:vb.net}
'Declaration
Public NotInheritable Class XmlCommentWriter
	Inherits System.Xml.XmlWriter
        Implements System.IDisposable
{code:vb.net}

For details regarding constructors and methods see the [XmlWriter](http://msdn.microsoft.com/en-us/library/system.xml.xmlwriter(v=vs.110).aspx) documentation.

**Remarks**

Be sure to specify alternate global behaviors before serialization. If your solution is unable to use XmlCommentWriter, you can also specify these settings when constructing an instance of XmlCommentElement.

C#{code:c#}
public enum Feature
{
    Leather,
    [XmlEnum("BlueRay")](XmlEnum(_BlueRay_))
    DVD,
    SatNav,
    ClimateControl
}

public class Vehicle : XmlAnnotate
{
    [XmlComment("Alphanumeric text name of the vehicle to order from the supplier")](XmlComment(_Alphanumeric-text-name-of-the-vehicle-to-order-from-the-supplier_))
    public string Name;
    [XmlComment(Min = 1, Max = 5, Default = 1)](XmlComment(Min-=-1,-Max-=-5,-Default-=-1))
    public short Quantity;
    [DefaultValue(false)](DefaultValue(false))
    public bool CreditChecked;
    [XmlArrayItem("Option", typeof(Extra))](XmlArrayItem(_Option_,-typeof(Extra)))
    public List<object> Options = new List<object>();
}

public class Extra : XmlAnnotate
{
    public Feature Type;
    [XmlComment(Min = 0, Max = 150)](XmlComment(Min-=-0,-Max-=-150))
    public string Comment;
}

public void CreateOrder(Order order, FileInfo file)
{
    var settings = new XmlWriterSettings();
    settings.Indent = true;
    using (var writer = new XmlCommentWriter(file.FullName, settings))
    {
        writer.Alphabetize = true;
        writer.Metadata = true;
        writer.MaxLength = 50;
        writer.Repeat = true;
        var serialiser = new XmlSerializer(order.GetType());
        serialiser.Serialize(writer, order);
    }
}
{code:c#}

VB{code:vb.net}
Public Enum Feature
    Leather
    <XmlEnum("BlueRay")>
    DVD
    SatNav
    ClimateControl
End Enum

Public Class Vehicle
    Inherits XmlAnnotate
    <XmlComment("Alphanumeric text name of the vehicle to order from the supplier")>
    Public Property Name As String
    <XmlComment(Min:=1, Max:=5, Default:=1)>
    Public Property Quantity As Short
    Public Property CreditChecked As Boolean
    <XmlArrayItem("Option", GetType(Extra))>
    Public Property Options As New List(Of Extra)
End Class

Public Class Extra
    Inherits XmlAnnotate
    Public Property Type As Feature
    <XmlComment(Min:=0, Max:=150)>
    Public Property Comment As String
End Class

Public Sub CreateOrder(ByRef Order As Order, ByRef File As FileInfo)
    Dim Settings As New XmlWriterSettings()
    Settings.Indent = True
    Using Writer As New XmlCommentWriter(File.FullName, Settings)
        Writer.Alphabetize = True
        Writer.Metadata = True
        Writer.MaxLength = 50
        Writer.Repeat = True
        Dim Serializer As New XmlSerializer(Order.GetType())
        Serializer.Serialize(Writer, Order)
    End Using
End Sub
{code:vb.net}

XML{code:xml}
<Vehicle>
  <!-- CreditChecked: Either true or false. Defaults to false -->
  <!-- Name: Alphanumeric text name of the vehicle to order from ... -->
  <!-- ... the supplier -->
  <!-- Options: Zero or more elements of type Option -->
  <!-- Quantity: Whole number between 1 and 5. Defaults to 1 -->
  <Name>Murciélago</Name>
  <Quantity>1</Quantity>
  <CreditChecked>true</CreditChecked>
  <Options>
    <Option>
      <!-- Comment: Alphanumeric text between 0 and 150 characters -->
      <!-- Type: One of Leather, BlueRay, SatNav, ClimateControl -->
      <Type>ClimateControl</Type>
    </Option>
    <Option>
      <!-- Comment: Alphanumeric text between 0 and 150 characters -->
      <!-- Type: One of Leather, BlueRay, SatNav, ClimateControl -->
      <Type>Leather</Type>
      <Comment>Black</Comment>
    </Option>
  </Options>
</Vehicle>
{code:xml}

If classes that implement XmlAnnotate, or properties or fields are specified of type XmlCommentElement; when serializing without using the XmlCommentWriter, a redundant element will output to the resultant XML but does not cause any error when deserialized. In addition, the default settings apply unless they have been specified in the constructor of XmlCommentElement. For example:

{code:xml}
<Vehicle>
  <Comment xmlns="http://www.30e6b941-728b-4a0d-b215-56fe5c470ff9.org/">
    <!-- Name: Alphanumeric text name of the vehicle to order from the supplier -->
    <!-- Quantity: Whole number between 1 and 5. Defaults to 1 -->
    <!-- CreditChecked: Either true or false. Defaults to false -->
    <!-- Options: Zero or more elements of type Option -->
  </Comment>
  <Name>Murciélago</Name>
  <Quantity>1</Quantity>
  <CreditChecked>true</CreditChecked>
  <Options>
    <Option>
      <Comment xmlns="http://www.30e6b941-728b-4a0d-b215-56fe5c470ff9.org/">
        <!-- Type: One of Leather, BlueRay, SatNav, ClimateControl -->
        <!-- Comment: Alphanumeric text between 0 and 150 characters -->
      </Comment>
      <Type>ClimateControl</Type>
    </Option>
    <Option>
      <Comment xmlns="http://www.30e6b941-728b-4a0d-b215-56fe5c470ff9.org/" />
      <Type>Leather</Type>
      <Comment>Black</Comment>
    </Option>
  </Options>
</Vehicle>
{code:xml}

XmlCommentWriter has to implement and hide the Dispose() method implemented on XmlWriter as the garbage collector does not check for the IDisposable interface on inherited classes. This implementation delegates to the Dispose() on the XmlWriter instance.