**3. Annotate classes with XmlComment and specify other settings**

The XmlComment attribute has several named parameters to control output of comments. The XmlCommentsWriter class has properties that determine the general behavior of comment output. Embed the XmlComment attribute as required and alter global settings. For example:

C#{code:c#}
public enum Feature
{
    Leather,
    [XmlEnum("BlueRay")](XmlEnum(_BlueRay_))
    DVD,
    SatNav,
    ClimateControl
}

public class Vehicle : XmlAnnotate
{
    [XmlComment("Alphanumeric text name of the vehicle to order from the supplier")](XmlComment(_Alphanumeric-text-name-of-the-vehicle-to-order-from-the-supplier_))
    public string Name;
    [XmlComment(Min = 1, Max = 5, Default = 1)](XmlComment(Min-=-1,-Max-=-5,-Default-=-1))
    public short Quantity;
    [DefaultValue(false)](DefaultValue(false))
    public bool CreditChecked;
    [XmlArrayItem("Option", typeof(Extra))](XmlArrayItem(_Option_,-typeof(Extra)))
    public List<Extra> Options = new List<Extra>();
}

public class Extra : XmlAnnotate
{
    public Feature Type;
    [XmlComment(Min = 0, Max = 150)](XmlComment(Min-=-0,-Max-=-150))
    public string Comment;
}

public void CreateOrder(Order order, FileInfo file)
{
    var settings = new XmlWriterSettings();
    settings.Indent = true;
    using (var writer = new XmlCommentWriter(file.FullName, settings))
    {
        writer.Metadata = true; // Includes comments based on Type metadata
        writer.Alphabetize = true; // Organize comments alphabetically
        var serialiser = new XmlSerializer(order.GetType());
        serialiser.Serialize(writer, order);
    }
}
{code:c#}

VB{code:vb.net}
Public Enum Delivery
    Leather
    <XmlEnum("BlueRay")>
    DVD
    SatNav
    ClimateControl
End Enum

Public Class Vehicle
    Inherits XmlAnnotate
    <XmlComment("Alphanumeric text name of the vehicle to order from the supplier")>
    Public Property Name As String
    <XmlComment(Min:=1, Max:=5, Default:=1)>
    Public Property Quantity As Short
    <DefaultValue(False)>
    Public Property CreditChecked As Boolean
    <XmlArrayItem("Option", GetType(Extra))>
    Public Property Options As New List(Of Extra)
End Class

Public Class Extra
    Inherits XmlAnnotate
    Public Property Type As Feature
    <XmlComment(Min:=0, Max:=150)>
    Public Property Comment As String
End Class

Public Sub CreateOrder(ByRef Order As Order, ByRef File As FileInfo)
    Dim Settings As New XmlWriterSettings()
    Settings.Indent = True
    Using Writer As New XmlCommentWriter(File.FullName, Settings)
        Writer.Metadata = True ' Includes comments based on Type metadata
        Writer.Alphabetize = True ' Organize comments alphabetically
        Dim Serializer As New XmlSerializer(Order.GetType())
        Serializer.Serialize(Writer, Order)
    End Using
End Sub
{code:vb.net}

Resultant XML for a populated vehicle order may look like this:

{code:xml}
<Vehicle>
  <!-- CreditChecked: Either true or false. Defaults to false -->
  <!-- Name: Alphanumeric text name of the vehicle to order from the supplier -->
  <!-- Options: Zero or more elements of type Option -->
  <!-- Quantity: Whole number between 1 and 5. Defaults to 1 -->
  <Name>Murciélago</Name>
  <Quantity>1</Quantity>
  <CreditChecked>true</CreditChecked>
  <Options>
    <Option>
      <!-- Comment: Alphanumeric text between 0 and 150 characters -->
      <!-- Type: One of Leather, BlueRay, SatNav, ClimateControl -->
      <Type>ClimateControl</Type>
    </Option>
    <Option>
      <Type>Leather</Type>
      <Comment>Black</Comment>
    </Option>
  </Options>
</Vehicle>
{code:xml}

Without setting XmlCommentWriter Metadata and Alphabetize, the resultant XML may look like this:

{code:xml}
<Vehicle>
  <!-- Name: Alphanumeric text name of the vehicle to order from the supplier -->
  <!-- Quantity: Whole number between 1 and 5. Defaults to 1 -->
  <Name>Murciélago</Name>
  <Quantity>1</Quantity>
  <CreditChecked>true</CreditChecked>
  <Options>
    <Option>
      <!-- Comment: Alphanumeric text between 0 and 150 characters -->
      <Type>ClimateControl</Type>
    </Option>
    <Option>
      <Type>Leather</Type>
      <Comment>Black</Comment>
    </Option>
  </Options>
</Vehicle>
{code:xml}

>{[Learn more](Documentation)}>

