**1. Inherit from XmlAnnotate**

The XmlAnnotate class provides a default implementation to allow comments to appear embedded within the XML element of the class that is serialized. Inherit XmlAnnotate on each class that is being serialized where comments are required. For example:

C#{code:c#}
using System.Collections.Generic;
using XmlCommentSerialization;

public enum Feature
{
    Leather,
    DVD,
    SatNav,
    ClimateControl
}

public class Vehicle : XmlAnnotate
{
    public string Name;
    public short Quantity;
    public bool CreditChecked;
    public List<Extra> Options = new List<Extra>();
}

public class Extra : XmlAnnotate
{
    public Feature Type;
    public string Comment;
}
{code:c#}

VB{code:vb.net}
Imports System.Collections.Generic
Imports XmlCommentSerialization

Public Enum Feature
    Leather
    DVD
    SatNav
    ClimateControl
End Enum

Public Class Vehicle
    Inherits XmlAnnotate
    Public Property Name As String
    Public Property Quantity As Short
    Public Property CreditChecked As Boolean
    Public Property Options As New List(Of Extra)
End Class

Public Class Extra
    Inherits XmlAnnotate
    Public Property Type As Feature
    Public Property Comment As String
End Class
{code:vb.net}

>{[Next Step >](Getting-Started-Step-2-of-3)}>

