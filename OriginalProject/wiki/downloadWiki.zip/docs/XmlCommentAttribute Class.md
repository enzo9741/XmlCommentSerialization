# XmlCommentAttribute Class

This class inherits [Attribute](http://msdn.microsoft.com/en-us/library/system.attribute(v=vs.110).aspx). Specifies the comment for the attribute or element, an expected range, the default value, or if commenting should be suppressed.

C#{code:c#}
[AttributeUsage(AttributeTargets.Property ](-AttributeTargets.Field))
public sealed class XmlCommentAttribute : System.Attribute
{code:c#}

VB{code:vb.net}
'Declaration
<AttributeUsage(AttributeTargets.Property Or AttributeTargets.Field)>
Public NotInheritable Class XmlCommentAttribute
        Implements System.Attribute
{code:vb.net}

**Constructors**

|| Name || Description ||
| XmlCommentAttribute() | Initializes a new instance of the XmlCommentAttribute class. |
| XmlCommentAttribute(String) | Initializes a new instance of the XmlCommentAttribute class and specifies the comment to include in the XML output. |
**Properties**

|| Name || Description || Type || Default ||
| Comment | Text that will become the XML comment. This text replaces the Type metadata comment unless TypeData is true | String | null |
| Default | What will be the default value in the property or field when deserializing XML that has the attribute or element omitted | Object | null |
| Ignore | Don't output XML comment for this attribute or element | Boolean | false |
| Max | The maximum value or length expected in the attribute or element | Object | null |
| Min | The minimum value or length expected in the attribute or element | Object | null |
| TypeData | Type metadata should be included in the XML comment even when a Text Comment or a Description attribute is specified | Boolean | false |
For details regarding inherited properties and methods see the [Attribute](http://msdn.microsoft.com/en-us/library/system.attribute(v=vs.110).aspx) documentation.

**Remarks**

Explain the usage scenarios.