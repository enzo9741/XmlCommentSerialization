# XmlCommentElement Class

This class implements [IXmlSerializable](http://msdn.microsoft.com/en-us/library/system.xml.serialization.ixmlserializable(v=vs.110).aspx) and is instantiated in XmlAnnotate. Properties or fields of this type can be implemented in serialized classes when inheriting XmlAnnotate is not possible or undesired. In the constructor its possible to alter the default settings that would otherwise be specified globally with static properties.

C#{code:c#}
public sealed class XmlCommentElement : System.Xml.Serialization.IXmlSerializable
{code:c#}

VB{code:vb.net}
'Declaration
Public NotInheritable Class XmlCommentElement
        Implements System.Xml.Serialization.IXmlSerializable
{code:vb.net}

**Constructors**

|| Name || Description ||
| XmlCommentElement() | Required for Serialization. Not to be used in code. |
| XmlCommentElement(Type, Int32, Boolean, Boolean, Boolean) | Annotates the Type specified during serialization using the settings specified. |
**Constants**

|| Name || Description || Type || Default ||
| ElementName | Element name used to enable comments in XML output | String | Comment |
| Namespace | Unique namespace that XmlCommentWriter relies upon to detect when to suppress the redundant Comment element. | String | http://www.30e6b941-728b-4a0d-b215-56fe5c470ff9.org/ |
**Static Properties**

|| Name || Description || Type || Default ||
| Alphabetize | Order attribute and element comments alphabetically | Boolean | false |
| Metadata | Output comments from Type metadata | Boolean | true |
| MaxLength | Maximum comment length before wrapping. Zero means no wrap | Int32 | 0 |
| Repeat | Output comments each time the Type appears in the XML | Boolean | false |

**Methods**

|| Name || Description ||
| GetSchema() | No schema defined at this time. Returns null. |
| ReadXml(XmlReader) | No in-memory representation of comments supported at this time. Returns null. |
| WriteXml(XmlWriter) | Outputs comments for the fields and properties on the Type that become elements and attributes in accordance with the settings specified. |

specified in the constructor and other settings specified on XmlCommentWriter or the constructor. |
**Remarks**

If serialization occurs against an instance of this class that has been constructed using the default zero parameter constructor, a NotSupportedException will occur. It is necessary to identify the Type to used for annotation prior to serialization.

