**Project Description**
Helps developers include comments and other self-documenting information in XML files produced using the Microsoft XML Serialization classes.

**Introduction**
When serializing and deserializing a class as XML using [XmlSerializer](http://msdn.microsoft.com/en-us/library/system.xml.serialization.xmlserializer(v=vs.110).aspx) its possible to decorate it with [attributes](http://msdn.microsoft.com/en-us/library/83y7df3e(v=vs.110).aspx) that control the structure such as the XML attribute or element name. What is lacking is an attribute that embeds comments when serializing to help describe these attributes and elements to aid in the readability and editing of the XML by those removed from the system source code. For example:

{code:xml}
<Vehicle>
    <!-- Name: Alphanumeric text name of the vehicle to order from the supplier -->
    <Name>Murciélago</Name>
</Vehicle>
{code:xml}

This project provides an XmlComment attribute to embed such comments:

C#{code:c#}
[XmlComment("Alphanumeric text name of the vehicle to order from the supplier")](XmlComment(_Alphanumeric-text-name-of-the-vehicle-to-order-from-the-supplier_))
public string Name;
{code:c#}

VB{code:vb.net}
<XmlComment("Alphanumeric text name of the vehicle to order from the supplier")>
Public Property Name As String
{code:vb.net}

This project also embeds comments from Type metadata:

{code:xml}
<Vehicle>
  <!-- Name: Alphanumeric text name of the vehicle to order from the supplier -->
  <!-- Delivery: One of Standard, Rush, VIP -->
  <!-- CreditChecked: Either true or false -->
  <Name>Murciélago</Name>
  <Delivery>Rush</Delivery>
  <CreditChecked>true</CreditChecked>
</Vehicle>
{code:xml}

This project is not an XML Serialization solution. This project relies upon having an instance of the XmlSerializer class. It is an addition for when there is a requirement to document XML. There are some requirements that must be satisfied in order for this project to work with your code.

C#{code:c#}
using XmlCommentSerialization;

public enum Delivery
{
    Standard,
    Rush,
    VIP
}

public class Vehicle : XmlAnnotate
{
    [XmlComment("Alphanumeric text name of the vehicle to order from the supplier")](XmlComment(_Alphanumeric-text-name-of-the-vehicle-to-order-from-the-supplier_))
    public string Name;
    public Delivery Delivery;
    public bool CreditChecked;
}
{code:c#}

VB{code:vb.net}
Imports XmlCommentSerialization

Public Enum Delivery
    Standard
    Rush
    VIP
End Enum

Public Class Vehicle
    Inherits XmlAnnotate
    <XmlComment("Alphanumeric text name of the vehicle to order from the supplier")>
    Public Property Name As String
    Public Property Delivery As Delivery
    Public Property CreditChecked As Boolean
End Class
{code:vb.net}

>{[Get Started](Documentation)}>

